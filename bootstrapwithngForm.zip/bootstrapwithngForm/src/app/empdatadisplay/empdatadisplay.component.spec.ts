import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpdatadisplayComponent } from './empdatadisplay.component';

describe('EmpdatadisplayComponent', () => {
  let component: EmpdatadisplayComponent;
  let fixture: ComponentFixture<EmpdatadisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpdatadisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpdatadisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
