import { Component, OnInit } from '@angular/core';
import{EmployeeData} from '../employee-data';
import{EmpDataService} from '../emp-data.service'
@Component({
  selector: 'app-employeedata',
  templateUrl: './employeedata.component.html',
  styleUrls: ['./employeedata.component.css']
})
export class EmployeedataComponent implements OnInit {

  constructor(private _empDataservice:EmpDataService) { }

  ngOnInit() {
  }
  setData(){
    console.log(this.empData.empFirstName)
    this._empDataservice.setData(this.empData)
  }
  empData= new EmployeeData('Ankush','','','','','','','','')
}
