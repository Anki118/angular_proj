import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-info',
  templateUrl: './cust-info.component.html',
  styleUrls: ['./cust-info.component.css']
})
export class CustInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  states=["Maharashtra","Gujarat","Uttar Pradesh"]

  getclicked(){
    alert('clicked');
  }
}
