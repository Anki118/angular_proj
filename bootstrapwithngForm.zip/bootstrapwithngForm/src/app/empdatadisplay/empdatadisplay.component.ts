import { Component, OnInit } from '@angular/core';
import{EmployeeData} from '../employee-data';
import {EmpDataService} from '../emp-data.service'
@Component({
  selector: 'app-empdatadisplay',
  templateUrl: './empdatadisplay.component.html',
  styleUrls: ['./empdatadisplay.component.css']
})
export class EmpdatadisplayComponent implements OnInit {

  constructor(private _empDataService:EmpDataService) { }

  ngOnInit() {
    this.empdet=this._empDataService.getData()
    console.log(this.empdet.empDept)
  }
  
 
  public empdet:EmployeeData
}
