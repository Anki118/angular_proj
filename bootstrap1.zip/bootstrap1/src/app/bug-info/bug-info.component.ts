import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import{DataService} from '../data.service';
@Component({
  selector: 'app-bug-info',
  templateUrl: './bug-info.component.html',
  styleUrls: ['./bug-info.component.css']
})
export class BugInfoComponent implements OnInit {

  constructor(private _data:DataService) { }

  ngOnInit() {
 
  }
  ngDoCheck(){
    this._data.debugInfo(this.date,this.time,this.impact,this.comment)
  }
  public date="";
  public time="";
  public impact="";
  public comment="";
  
  
}
