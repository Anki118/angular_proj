import { Component } from '@angular/core';
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable} from 'rxjs';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'My Firebase';

  public goldData:Observable<any[]>
  public silverData:Observable<any[]>
  constructor(private  _db:AngularFirestore){
    this.goldData=_db.collection('/Gold').valueChanges()
    this.silverData=_db.collection('/Silver').valueChanges()
  }

 
}
