import { Directive, ElementRef, HostListener,Renderer  } from '@angular/core';

@Directive({
  selector: '[appCompSuccess]'
})
export class CompSuccessDirective {

  constructor(private el:ElementRef,private renderer: Renderer) { }

 
  @HostListener ('mouseenter') onmouseenter(){
    this.setText('green')
  }
  @HostListener('mouseleave') onmouseleave(){
    this.setText('black')
  }
  setText (param:string){
    this.el.nativeElement.style.color=param;
}

}
