export class EmployeeData {
   
    constructor(
            public empFirstName:string,
            public empLastName:string,
            public hDate:string,
            public empTitle:string,
            public empDept:string,
            public empRank:string,
            public empDetail:string,
            public supFirstName:string,
            public supLastName:string
    ){
        
        }
    
         
}
