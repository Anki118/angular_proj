import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform {

  transform(value: number, param:any): any {
    let num=value;
    if(param=="Even"){
      return num%2==0?"It is Even":"It is not Even";
    }
    if(param=="Odd"){
      return num%2==0?"It is not Odd":"It is Odd";
    }
    if(param=="Prime"){
      if(num < 2) return "It is not Prime";
      for (var i = 2; i <= num/2; i++) {
          if(num%i==0)
              return "It is not prime";
      }
      return "It is prime";
    }
   if(param=="Perfect"){
      let temp:number=0;
      for(i=1;i<=num/2;i++){
          if(num%i==0){
            temp+=i
          }
      }
      return temp==num&&temp!=0?"It is Perfect":"It is not perfect"
   }
  
  }

}
