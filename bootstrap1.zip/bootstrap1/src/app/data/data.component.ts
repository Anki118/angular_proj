import { Component, OnInit, Output } from '@angular/core';
import{DataService} from '../data.service';
@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {

  constructor( private _data:DataService) { 
  
  }

  ngOnInit() {
   this.firstName=this._data.fname
   this.lastName=this._data.lname
   this.email=this._data.email
   this.date=this._data.date
   this.time=this._data.time
   this.impact=this._data.impact
   this.comment=this._data.comments
  }
 public firstName;
 public lastName;
 public email;
 public date;
 public time;
 public impact;
 public comment;
}
