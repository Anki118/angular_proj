import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MarvellousBootstrap';

  public personalInfo;
  public bugInfo;
  /*public formData={
    "firstName":this.personalInfo.firstName,
    "lastName":this.personalInfo.lastName,
    "email":this.personalInfo.email,
    "date":this.bugInfo.date,
    "time":this.bugInfo.time,
    "impact":this.bugInfo.impact,
    "comment":this.bugInfo.comment
  }*/
}
