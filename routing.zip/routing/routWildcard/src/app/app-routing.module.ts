import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { componentFactoryName } from '@angular/compiler';

import { AppComponent } from './app.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { BooksComponent } from './books/books.component';
import { ErrorComponent } from './error/error.component';

//Array of Routes in application
const routes: Routes = [
  {path : 'technologies', component:TechnologiesComponent},
  {path : 'books' ,component:BooksComponent},
  //Add on default path
  { path: '', component:TechnologiesComponent},
  // It is our Wildcard component
  {path : '**', component:ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
