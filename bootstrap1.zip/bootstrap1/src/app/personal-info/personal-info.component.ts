import { Component, OnInit , EventEmitter, Output} from '@angular/core';
import{DataService} from '../data.service';
@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent implements OnInit {

  constructor(private _data:DataService) { }

  ngOnInit() {
   
  }
  ngDoCheck(){
    console.log("method call")
    this._data.personalInfo(this.firstName,this.lastName,this.email)
  }
  public firstName="";
  public lastName="";
  public email="";
 
}
