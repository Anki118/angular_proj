import { Directive, ElementRef, HostListener ,Renderer} from '@angular/core';


@Directive({
  selector: '[appCompFailure]'
})
export class CompFailureDirective {

  constructor(private el:ElementRef,private renderer: Renderer) { }

  @HostListener ('mouseenter') onmouseenter(){
    this.setText('red')
  }
  @HostListener('mouseleave') onmouseleave(){
    this.setText('black')
  }
  setText (param:string){
    this.el.nativeElement.style.color=param;
}
 
}
