import { Injectable } from '@angular/core';
import{EmployeeData} from './employee-data'
@Injectable({
  providedIn: 'root'
})
export class EmpDataService {

  constructor() { }
  empdata:EmployeeData
  
   setData(employeeData:EmployeeData){
     console.log(employeeData.empDept)
    this.empdata=employeeData
  }
  getData(){
    console.log(this.empdata.empDept)
    return this.empdata
  }
}
