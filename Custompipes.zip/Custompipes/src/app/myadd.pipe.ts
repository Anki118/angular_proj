import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myadd'
})
export class MyaddPipe implements PipeTransform {

  transform(value: number, param:string): number {

    let res:number=value+parseInt(param);
    return res;
  }

}
