import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myRev'
})
export class MyRevPipe implements PipeTransform {

  transform(value: string): string {
    let str=value;
    let arr=str.split("");
    arr=arr.reverse();
    let temp=arr.join("");
    return temp;
  }

}
