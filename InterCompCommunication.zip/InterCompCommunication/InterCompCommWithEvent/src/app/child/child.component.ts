import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public message
  @Output() public myEvent=new EventEmitter()

  public sendData(){
    this.myEvent.emit(this.message)
  }

  
}
