import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService 
{
 constructor() { }
 public fname
 public lname
 public email
 public date
 public time
 public impact
 public comments
 personalInfo(fname,lname,email){
    this.fname=fname
    this.lname=lname
    this.email=email
 }
debugInfo(date,time,impact,comments){
    this.date=date
    this.time=time
    this.impact=impact
    this.comments=comments
}
}